class_prepared = object()

pre_init= object()
post_init = object()

pre_save = object()
post_save = object()

pre_delete = object()
post_delete = object()

post_syncdb = object()
